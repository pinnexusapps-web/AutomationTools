@echo off
title Excel Multi-Macro Auto-Installer

net session >nul 2>&1
if %errorLevel% == 0 (
    goto gotAdmin
) else (
    goto UACPrompt
)

:UACPrompt
    echo Requesting Administrative Privileges...
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    pushd "%~dp0"

echo ====================================================
echo        EXCEL MULTI-MACRO AUTO-INSTALLER TOOLS          
echo ====================================================
echo.
echo Step 1: Modifying Windows Registry for Excel VBA Access...

reg add "HKCU\Software\Microsoft\Office\14.0\Excel\Security" /v AccessVBOM /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\15.0\Excel\Security" /v AccessVBOM /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\16.0\Excel\Security" /v AccessVBOM /t REG_DWORD /d 1 /f >nul 2>&1

echo Registry updated successfully!
echo.
echo Step 2: Injecting 3 VBA Modules into Personal Macro Workbook...

echo Set objExcel = CreateObject("Excel.Application") > "%temp%\multi_injector.vbs"
echo objExcel.Visible = False >> "%temp%\multi_injector.vbs"
echo objExcel.DisplayAlerts = False >> "%temp%\multi_injector.vbs"
echo On Error Resume Next >> "%temp%\multi_injector.vbs"
echo appData = CreateObject("WScript.Shell").ExpandEnvironmentStrings("%%APPDATA%%") >> "%temp%\multi_injector.vbs"
echo xlStartPath = appData ^& "\Microsoft\Excel\XLSTART" >> "%temp%\multi_injector.vbs"
echo Set fso = CreateObject("Scripting.FileSystemObject") >> "%temp%\multi_injector.vbs"
echo If fso.FolderExists(xlStartPath) = False Then fso.CreateFolder(xlStartPath) >> "%temp%\multi_injector.vbs"
echo personalPath = xlStartPath ^& "\PERSONAL.XLSB" >> "%temp%\multi_injector.vbs"

echo If fso.FileExists(personalPath) Then >> "%temp%\multi_injector.vbs"
echo     Set objWorkbook = objExcel.Workbooks.Open(personalPath) >> "%temp%\multi_injector.vbs"
echo Else >> "%temp%\multi_injector.vbs"
echo     Set objWorkbook = objExcel.Workbooks.Add >> "%temp%\multi_injector.vbs"
echo     objWorkbook.SaveAs personalPath, 51 >> "%temp%\multi_injector.vbs"
echo End If >> "%temp%\multi_injector.vbs"

echo currentDir = fso.GetAbsolutePathName(".") >> "%temp%\multi_injector.vbs"

echo Set mod1 = objWorkbook.VBProject.VBComponents("DailyReportModule") >> "%temp%\multi_injector.vbs"
echo If Not mod1 Is Nothing Then objWorkbook.VBProject.VBComponents.Remove(mod1) >> "%temp%\multi_injector.vbs"
echo If fso.FileExists(currentDir ^& "\DailyReportModule.bas") Then objWorkbook.VBProject.VBComponents.Import(currentDir ^& "\DailyReportModule.bas") >> "%temp%\multi_injector.vbs"

echo Set mod2 = objWorkbook.VBProject.VBComponents("BioTimeModule") >> "%temp%\multi_injector.vbs"
echo If Not mod2 Is Nothing Then objWorkbook.VBProject.VBComponents.Remove(mod2) >> "%temp%\multi_injector.vbs"
echo If fso.FileExists(currentDir ^& "\BioTimeModule.bas") Then objWorkbook.VBProject.VBComponents.Import(currentDir ^& "\BioTimeModule.bas") >> "%temp%\multi_injector.vbs"

echo Set mod3 = objWorkbook.VBProject.VBComponents("ReceivingModule") >> "%temp%\multi_injector.vbs"
echo If Not mod3 Is Nothing Then objWorkbook.VBProject.VBComponents.Remove(mod3) >> "%temp%\multi_injector.vbs"
echo If fso.FileExists(currentDir ^& "\ReceivingModule.bas") Then objWorkbook.VBProject.VBComponents.Import(currentDir ^& "\ReceivingModule.bas") >> "%temp%\multi_injector.vbs"

echo objWorkbook.Save >> "%temp%\multi_injector.vbs"
echo objExcel.Quit >> "%temp%\multi_injector.vbs"

cscript //nologo "%temp%\multi_injector.vbs"
del "%temp%\multi_injector.vbs"

echo.
echo ====================================================
echo   SUCCESS! All 3 Macros installed in PERSONAL.XLSB:
echo   1. Daily Report (script.bas)
echo   2. Bio Data (biodata.bas)
echo   3. Receivings (receivings.bas)
echo ====================================================
echo.
pause
exit