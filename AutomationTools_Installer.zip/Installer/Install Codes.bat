@echo off
title Excel Multi-Macro Standard Installer
pushd "%~dp0"

echo ====================================================
echo      EXCEL MULTI-MACRO STANDARD INSTALLER (NO ADMIN)          
echo ====================================================
echo.
echo Step 1: Preparing Personal Macro Workbook...

echo Set objExcel = CreateObject("Excel.Application") > "%temp%\user_injector.vbs"
echo objExcel.Visible = False >> "%temp%\user_injector.vbs"
echo objExcel.DisplayAlerts = False >> "%temp%\user_injector.vbs"
echo On Error Resume Next >> "%temp%\user_injector.vbs"
echo appData = CreateObject("WScript.Shell").ExpandEnvironmentStrings("%%APPDATA%%") >> "%temp%\user_injector.vbs"
echo xlStartPath = appData ^& "\Microsoft\Excel\XLSTART" >> "%temp%\user_injector.vbs"
echo Set fso = CreateObject("Scripting.FileSystemObject") >> "%temp%\user_injector.vbs"
echo If fso.FolderExists(xlStartPath) = False Then fso.CreateFolder(xlStartPath) >> "%temp%\user_injector.vbs"
echo personalPath = xlStartPath ^& "\PERSONAL.XLSB" >> "%temp%\user_injector.vbs"

echo If fso.FileExists(personalPath) Then >> "%temp%\user_injector.vbs"
echo     Set objWorkbook = objExcel.Workbooks.Open(personalPath) >> "%temp%\user_injector.vbs"
echo Else >> "%temp%\user_injector.vbs"
echo     Set objWorkbook = objExcel.Workbooks.Add >> "%temp%\user_injector.vbs"
echo     objWorkbook.SaveAs personalPath, 51 >> "%temp%\user_injector.vbs"
echo End If >> "%temp%\user_injector.vbs"

echo currentDir = fso.GetAbsolutePathName(".") >> "%temp%\user_injector.vbs"
echo echo "Injecting modules..." >> "%temp%\user_injector.vbs"

:: Module 1: Daily Report Script
echo Set mod1 = objWorkbook.VBProject.VBComponents("DailyReportModule") >> "%temp%\user_injector.vbs"
echo If Not mod1 Is Nothing Then objWorkbook.VBProject.VBComponents.Remove(mod1) >> "%temp%\user_injector.vbs"
echo If fso.FileExists(currentDir ^& "\DailyReportModule.bas") Then objWorkbook.VBProject.VBComponents.Import(currentDir ^& "\DailyReportModule.bas") >> "%temp%\user_injector.vbs"

:: Module 2: Bio Data Script
echo Set mod2 = objWorkbook.VBProject.VBComponents("BioTimeModule") >> "%temp%\user_injector.vbs"
echo If Not mod2 Is Nothing Then objWorkbook.VBProject.VBComponents.Remove(mod2) >> "%temp%\user_injector.vbs"
echo If fso.FileExists(currentDir ^& "\BioTimeModule.bas") Then objWorkbook.VBProject.VBComponents.Import(currentDir ^& "\BioTimeModule.bas") >> "%temp%\user_injector.vbs"

:: Module 3: Receivings Script
echo Set mod3 = objWorkbook.VBProject.VBComponents("ReceivingModule") >> "%temp%\user_injector.vbs"
echo If Not mod3 Is Nothing Then objWorkbook.VBProject.VBComponents.Remove(mod3) >> "%temp%\user_injector.vbs"
echo If fso.FileExists(currentDir ^& "\ReceivingModule.bas") Then objWorkbook.VBProject.VBComponents.Import(currentDir ^& "\ReceivingModule.bas") >> "%temp%\user_injector.vbs"

echo objWorkbook.Save >> "%temp%\user_injector.vbs"
echo objExcel.Quit >> "%temp%\user_injector.vbs"

echo.
echo Step 2: Injecting 3 VBA Modules into PERSONAL.XLSB...
cscript //nologo "%temp%\user_injector.vbs"
del "%temp%\user_injector.vbs"

echo.
echo ====================================================
echo   SUCCESS! All 3 Macros installed in PERSONAL.XLSB:
echo   1. Daily Report (script.bas)
echo   2. Bio Data (biodata.bas)
echo   3. Receivings (receivings.bas)
echo   
echo   *Note: If macros don't show up, please check if
echo   "Trust access to the VBA project object model" 
echo   is enabled in Excel Macro Settings.
echo ====================================================
echo.
pause
exit